# LifeFlow (PWA): como publicar e instalar

Arquivos do pacote: `index.html`, `manifest.webmanifest`, `sw.js` e os três ícones `.png`. Todos precisam ficar **juntos, na mesma pasta**.

## Opção A: pelo computador (a mais rápida)
1. Descompacte o .zip.
2. Acesse **app.netlify.com/drop** e crie uma conta gratuita.
3. Arraste a pasta inteira para a página. Em segundos você recebe um endereço `https://...netlify.app`.

## Opção B: só pelo celular (GitHub Pages)
1. Crie uma conta gratuita em **github.com** e toque em **New repository** (nome: `lifeflow`, público).
2. Em **Add file > Upload files**, envie os 6 arquivos descompactados e toque em **Commit changes**.
3. Vá em **Settings > Pages**, escolha **Deploy from a branch**, branch `main`, pasta `/ (root)`, e salve.
4. Em 1 a 2 minutos o endereço `https://SEUUSUARIO.github.io/lifeflow/` fica no ar.

## Instalar no celular
- **Android (Chrome):** abra o endereço, toque no menu (três pontos) e em **Instalar app**.
- **iPhone (Safari):** abra o endereço, toque em **Compartilhar** e em **Adicionar à Tela de Início**.

## Bom saber
- Depois da primeira abertura com internet, o app funciona offline.
- Os dados ficam só no aparelho. Use **Configurações > Backup > Exportar** de vez em quando e **Importar** para trocar de celular.
- Os lembretes avisam enquanto o app estiver aberto. Não dá para avisar com o app fechado sem um servidor de notificações.
- Para atualizar o app depois, troque os arquivos e aumente o número em `const V='lifeflow-v1'` no `sw.js` (por exemplo, `v2`).
